import '../../../../core/theme/app_palette.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/resources/app_sizes.dart';
import '../../../../core/resources/app_strings.dart';
import '../../../../core/utils/snackbar_utils.dart';
import '../../../../core/widgets/jbb_card.dart';
import '../../../../core/widgets/jbb_empty_state.dart';
import '../../../../core/widgets/jbb_loading.dart';

import '../providers/notification_provider.dart';

class NotificationsScreen extends ConsumerWidget {
  const NotificationsScreen({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) => Scaffold(
    appBar: AppBar(title: Text(AppStrings.notifications)),
    body: ListView(
      padding: const EdgeInsets.all(AppSizes.s16),
      children: [
        ref
            .watch(notificationsProvider)
            .when(
              data: (items) => items.isEmpty
                  ? JbbEmptyState(message: AppStrings.youReAllCaughtUp)
                  : Column(
                      children: items
                          .map(
                            (n) => JbbCard(
                              onTap: () async {
                                try {
                                  await ref
                                      .read(notificationRepositoryProvider)
                                      .markRead(n.id);
                                } catch (e) {
                                  if (context.mounted) {
                                    showMessage(context, friendlyError(e));
                                  }
                                }
                              },
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      if (n.isRead != true) ...[
                                        Container(
                                          width: AppSizes.s8,
                                          height: AppSizes.s8,
                                          decoration: BoxDecoration(
                                            color: context.palette.accent,
                                            shape: BoxShape.circle,
                                          ),
                                        ),
                                        const SizedBox(width: AppSizes.s8),
                                      ],
                                      Expanded(
                                        child: Text(
                                          n.title,
                                          style: const TextStyle(
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                  SizedBox(height: AppSizes.s8),
                                  Text(n.body),
                                  if (n.isRead != true)
                                    Padding(
                                      padding: EdgeInsets.only(
                                        top: AppSizes.s10,
                                      ),
                                      child: Text(
                                        AppStrings.uiTapToMarkAsRead,
                                        style: TextStyle(
                                          color: context.palette.textSecondary,
                                          fontSize: AppSizes.font12,
                                        ),
                                      ),
                                    ),
                                ],
                              ),
                            ),
                          )
                          .toList(),
                    ),
              error: (e, s) => JbbEmptyState(
                message: friendlyError(e),
                onRetry: () => ref.invalidate(notificationsProvider),
              ),
              loading: () => JbbLoading(),
            ),
      ],
    ),
  );
}
