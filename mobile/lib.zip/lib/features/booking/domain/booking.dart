class Booking {
  const Booking({
    required this.id,
    required this.userId,
    required this.className,
    required this.date,
    required this.endAt,
    required this.status,
    this.category,
    this.trainingType,
  });

  final String id;
  final String userId;
  final String className;
  final DateTime date;
  final DateTime endAt;
  final String status;
  final String? category, trainingType;
}
