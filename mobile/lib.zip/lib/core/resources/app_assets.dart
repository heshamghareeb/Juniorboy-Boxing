abstract final class AppAssets {
  static const header = 'assets/images/backgrounds/bg_home_header.png';
  static const homeHero = 'assets/images/backgrounds/bg_home_hero_logo.jpg';
  static const welcome = 'assets/images/backgrounds/logo_transparent.png';
  static const junior = 'assets/images/cards/card_program_junior.png';
  static const group = 'assets/images/cards/card_program_group.png';
  static const boxer = 'assets/images/photos/photo_kid_boxing.jpg';
}
