// swift-tools-version: 5.9
// The swift-tools-version declares the minimum version of Swift required to build this package.
//
// Generated file. Do not edit.
//

import PackageDescription

let package = Package(
    name: "FlutterGeneratedPluginSwiftPackage",
    platforms: [
        .iOS("15.0")
    ],
    products: [
        .library(name: "FlutterGeneratedPluginSwiftPackage", type: .static, targets: ["FlutterGeneratedPluginSwiftPackage"])
    ],
    dependencies: [
        .package(name: "cloud_firestore", path: "../.packages/cloud_firestore-6.10.0"),
        .package(name: "cloud_functions", path: "../.packages/cloud_functions-6.5.0"),
        .package(name: "connectivity_plus", path: "../.packages/connectivity_plus-7.3.1"),
        .package(name: "firebase_analytics", path: "../.packages/firebase_analytics-12.6.0"),
        .package(name: "firebase_app_check", path: "../.packages/firebase_app_check-0.4.8"),
        .package(name: "firebase_auth", path: "../.packages/firebase_auth-6.7.0"),
        .package(name: "firebase_core", path: "../.packages/firebase_core-4.15.0"),
        .package(name: "firebase_crashlytics", path: "../.packages/firebase_crashlytics-5.4.0"),
        .package(name: "firebase_messaging", path: "../.packages/firebase_messaging-16.7.0"),
        .package(name: "firebase_performance", path: "../.packages/firebase_performance-0.11.6"),
        .package(name: "firebase_storage", path: "../.packages/firebase_storage-13.6.0"),
        .package(name: "flutter_local_notifications", path: "../.packages/flutter_local_notifications-22.3.1"),
        .package(name: "google_sign_in_ios", path: "../.packages/google_sign_in_ios-5.9.0"),
        .package(name: "image_picker_ios", path: "../.packages/image_picker_ios-0.8.13+8"),
        .package(name: "sign_in_with_apple", path: "../.packages/sign_in_with_apple-8.2.0"),
        .package(name: "sqflite_darwin", path: "../.packages/sqflite_darwin-2.4.4"),
        .package(name: "stripe_ios", path: "../.packages/stripe_ios-14.1.0"),
        .package(name: "url_launcher_ios", path: "../.packages/url_launcher_ios-6.4.2"),
        .package(name: "FlutterFramework", path: "../.packages/FlutterFramework")
    ],
    targets: [
        .target(
            name: "FlutterGeneratedPluginSwiftPackage",
            dependencies: [
                .product(name: "cloud-firestore", package: "cloud_firestore"),
                .product(name: "cloud-functions", package: "cloud_functions"),
                .product(name: "connectivity-plus", package: "connectivity_plus"),
                .product(name: "firebase-analytics", package: "firebase_analytics"),
                .product(name: "firebase-app-check", package: "firebase_app_check"),
                .product(name: "firebase-auth", package: "firebase_auth"),
                .product(name: "firebase-core", package: "firebase_core"),
                .product(name: "firebase-crashlytics", package: "firebase_crashlytics"),
                .product(name: "firebase-messaging", package: "firebase_messaging"),
                .product(name: "firebase-performance", package: "firebase_performance"),
                .product(name: "firebase-storage", package: "firebase_storage"),
                .product(name: "flutter-local-notifications", package: "flutter_local_notifications"),
                .product(name: "google-sign-in-ios", package: "google_sign_in_ios"),
                .product(name: "image-picker-ios", package: "image_picker_ios"),
                .product(name: "sign-in-with-apple", package: "sign_in_with_apple"),
                .product(name: "sqflite-darwin", package: "sqflite_darwin"),
                .product(name: "stripe-ios", package: "stripe_ios"),
                .product(name: "url-launcher-ios", package: "url_launcher_ios"),
                .product(name: "FlutterFramework", package: "FlutterFramework")
            ]
        )
    ]
)
